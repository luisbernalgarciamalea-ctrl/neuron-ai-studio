const base = process.env.NEURON_BACKEND_URL || "https://neuron-backend-v2.vercel.app";

async function check(label, path, options = {}) {
  try {
    const response = await fetch(base + path, { ...options, signal: AbortSignal.timeout(70000) });
    const text = await response.text();
    let data;
    try { data = JSON.parse(text); } catch { data = text; }
    console.log(`${response.ok ? "PASS" : "FAIL"} ${label}: HTTP ${response.status}`);
    if (!response.ok) console.log("  ", typeof data === "string" ? data : data.error || data.details || data);
    return response.ok;
  } catch (error) {
    console.log(`FAIL ${label}: ${error.message}`);
    return false;
  }
}

const modes = [
  "chat", "research", "docs", "code", "math", "author", "designer",
  "poet", "video", "script", "humanizer", "business", "presentation", "logo"
];

let passed = 0;
let total = 0;
for (const path of ["/api/chat", "/api/search", "/api/image", "/api/video", "/api/music", "/api/auth"]) {
  total++;
  if (await check(`OPTIONS ${path}`, path, { method: "OPTIONS" })) passed++;
}

total++;
if (await check("search", "/api/search?q=artificial%20intelligence")) passed++;

total++;
if (await check("chat", "/api/chat", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    mode: "chat",
    payload: { message: "Reply with exactly: connection ok", plan: "Free", history: [], searchResults: [], language: "English" }
  })
})) passed++;

for (const mode of modes) {
  total++;
  if (await check(`mode ${mode}`, "/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      mode,
      payload: { message: "Reply with exactly: OK", plan: "Free", history: [], searchResults: [], language: "English" }
    })
  })) passed++;
}

console.log(`\n${passed}/${total} checks passed`);
if (passed !== total) process.exitCode = 1;
