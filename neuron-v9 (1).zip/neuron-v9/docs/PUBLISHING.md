# Publishing Neuron AI

## Important: a custom `.com` or `.ai` domain is normally not free

Vercel, Netlify, GitHub Pages, and Cloudflare Pages can host a site for free, but a custom domain such as `neuronai.com` or `neuron.ai` normally has an annual registration cost. A free `.com` or `.ai` domain is not a realistic permanent option.

Use the free host URL first, then buy the domain when the brand is ready:

- Vercel: `your-project.vercel.app`
- GitHub Pages: `username.github.io/project`
- Cloudflare Pages: `project.pages.dev`

## Recommended launch path

### Frontend on Vercel

1. Create a GitHub repository for the frontend.
2. Put `neuron.html` in the repository and rename it to `index.html`.
3. Put `neuron-logo.png` beside `index.html`.
4. Copy the entire `vendor/` folder beside `index.html`; it contains the local DOCX and PowerPoint libraries.
5. Import the repository into Vercel using the free Hobby plan.
6. Deploy with no build command and the output directory set to the project root.
7. Keep the backend URL in the frontend configuration as `https://neuron-backend-v2.vercel.app`.
8. If you use a different backend deployment, set `window.NEURON_BACKEND_URL` before the app script loads.

### Backend on Vercel

1. Keep the existing backend repository.
2. Put Gemini, Serper, MongoDB, and video-provider keys only in Vercel Project Settings → Environment Variables.
3. Redeploy after saving variables.
4. Test `/api/search` and `/api/chat` before connecting the frontend.
5. Add the optional `api/health.js` patch from this package.

## Making it appear in Google and Bing

1. Add a real public landing page with text describing Neuron AI.
2. Add a unique page title and meta description.
3. Add `robots.txt` and `sitemap.xml`.
4. Register the deployed URL in Google Search Console and Bing Webmaster Tools.
5. Submit the sitemap.
6. Publish useful pages for “AI writing assistant”, “AI book writer”, “AI research assistant”, and similar topics—but only make claims the service can actually support.
7. Earn legitimate links from your GitHub profile, product directories, social profiles, and relevant articles.
8. Add a privacy policy, terms, contact page, and a clear product description.

Search ranking is not immediate. A new site may take days or weeks to be discovered and longer to build authority. Do not use fake reviews, keyword stuffing, or generated spam pages.
