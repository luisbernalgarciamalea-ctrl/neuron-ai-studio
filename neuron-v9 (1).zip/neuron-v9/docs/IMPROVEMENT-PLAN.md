# Neuron AI V8 improvement plan

## What was improved in this package

- Uses the existing deployed backend at `https://neuron-backend-v2.vercel.app`.
- Keeps the backend URL in one configurable constant.
- Adds a backend-status control to the app header.
- Adds an optional Gemini model selector.
- Adds request timeouts and clearer backend errors.
- Limits the amount of chat history, prompt text, and search results sent per request.
- Adds a keyboard shortcut: Ctrl/Cmd + Enter sends the main message.
- Adds basic SEO metadata, Open Graph metadata, a favicon, and a theme color.
- Adds a sandbox to generated-code previews.
- Removes creator and premium codes from the public V8 frontend. Access control must be decided by the backend.
- Routes image generation through the deployed backend instead of exposing an image key in the browser.
- Keeps the original uploaded files unchanged.

## Recommended next improvements for production

### 1. Security

- Rotate any API keys that were ever committed to HTML or a public repository.
- Store provider keys only in Vercel environment variables.
- Enforce plan limits and creator privileges in the backend. Never trust `plan`, `isCreator`, or a promo code sent by the browser.
- Replace the current client-only login with server-side sessions or short-lived signed tokens.
- Replace the hard-coded password salt with a slow password hash such as Argon2id or bcrypt with a per-user salt.
- Restrict CORS to the real frontend domain instead of `*` after deployment.
- Add request rate limiting and abuse monitoring.

### 2. AI quality

- Keep Gemini Flash as the fast default and use Pro only for long or difficult tasks.
- Add a model router based on mode: Flash for chat, Pro for research and complex code.
- Add structured tool calling instead of asking the model to imitate tools in plain text.
- Add citations only from returned search results, with URL validation and source titles.
- Add a server-side conversation store if chats must survive a different browser/device.

### 3. Memory and files

- Add document upload, text extraction, chunking, embeddings, and retrieval.
- Store each user’s memory separately.
- Let the user view, edit, export, and delete saved memory.
- Never send all documents on every request; retrieve only relevant chunks.

### 4. Media

- Keep storyboard generation in `/api/chat` when no video provider is configured.
- Use a real image provider only through `/api/image`.
- Label media limits accurately; no hosted provider is truly unlimited for free.
- Add a job queue for long video renders so serverless requests do not time out.

### 5. Product and SEO

- Add a public landing page that explains the product without requiring login.
- Add pricing, privacy, terms, contact, and deletion pages.
- Add a sitemap, robots file, canonical URL, and Search Console verification.
- Add analytics only after a privacy notice and consent mechanism are in place.
- Publish useful pages for each major mode, rather than relying on one JavaScript application page.
