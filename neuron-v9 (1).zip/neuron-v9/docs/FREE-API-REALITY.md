# Free APIs: what is actually possible

There is no legitimate source of infinite free API keys. A key is an account credential, and trying to create or rotate accounts to bypass quotas can violate provider rules and get the project blocked.

## Closest options for Neuron

| Capability | Best no-cost approach | Real limitation |
|---|---|---|
| Text AI | Your existing Gemini backend free tier | Rate limits, model availability, and provider policy |
| Truly unmetered text requests | Run Ollama locally | Limited by your computer's RAM, GPU, speed, storage, and electricity |
| Web search | Your existing DuckDuckGo fallback or self-hosted SearXNG | Search engines can throttle or block automated traffic |
| Embeddings / memory | Local FAISS or Chroma | Limited by local storage and compute |
| Speech to text | Local faster-whisper | Limited by local hardware |
| Text to speech | Local Piper | Voice quality and local hardware |
| Images | Local ComfyUI/Stable Diffusion | Needs a capable GPU; hosted free image services have quotas |
| Video | Local tools or a paid/limited provider | Rendering is expensive; no reliable infinite hosted free option |

## Safe way to use free cloud providers

- Use one account and one key per provider.
- Keep keys in Vercel environment variables.
- Respect the documented rate limits.
- Add exponential backoff for temporary 429 errors.
- Show users a friendly "provider limit reached" message.
- Do not promise "unlimited" when the provider has quotas.

## Recommended Neuron architecture

1. Gemini Flash for fast everyday chat.
2. Gemini Pro only for hard tasks, research, and large code requests.
3. Optional Ollama fallback for a private local installation.
4. Local memory and embeddings for genuinely unlimited document storage.
5. External search and media providers treated as optional features with honest limits.
