# First fix completed: security and private configuration

This package uses only the current Neuron frontend/backend flow. The old V1–V5 files are not used.

## Changes made

- No provider API key is present in `frontend/neuron.html`.
- The creator identity is configured with the backend-only `CREATOR_EMAIL` environment variable.
- The chat, search, image, video, and auth route patches use shared CORS and browser-safety headers.
- Chat history, search results, user text, email, and mode values are bounded and sanitized before reaching Gemini.
- The backend model allowlist contains only the current Neuron choices used by the V8 frontend.
- The frontend status chip tests the backend endpoint without making a paid AI request.
- Generated code previews run in a sandboxed iframe.
- The optional health route reports only whether services are configured; it never returns secrets.

## How to apply the backend fix

1. Open the `neuron-backend-v2` GitHub repository.
2. Copy every file from `neuron-v8/backend-patch/api/` into its `api/` directory.
3. Copy `neuron-v8/backend-patch/package.json` and `neuron-v8/backend-patch/vercel.json` into the repository root.
4. In Vercel, set:

   - `GEMINI_KEY`
   - `CREATOR_EMAIL`
   - `FRONTEND_ORIGIN`
   - `MONGO_URI` if account storage is needed
   - optional media/search provider variables

5. Redeploy the backend.
6. Keep the frontend pointed at the deployed backend URL.

Do not commit `.env` files, API keys, database URLs, passwords, or tokens.
