// Neuron AI — /api/image
// Gemini image generation with model fallback chain
const https = require("https");
const { applyCors, handleOptions, cleanText } = require("./_security.js");

function getGeminiKeys() {
  const keys = [];
  const main = process.env.GEMINI_KEY;
  if (main && main.length > 8) keys.push(main);
  for (let i = 1; i <= 15; i++) {
    const k = process.env[`GEMINI_KEY_${i}`];
    if (k && k.length > 8 && !keys.includes(k)) keys.push(k);
  }
  return keys;
}

let kidx = 0;
function nextKey(keys) {
  const k = keys[kidx % keys.length]; kidx++; return k;
}

// Try models in order — first one that works wins
function fallbackImageUrl(prompt) {
  const seed = Math.floor(Math.random() * 2147483647);
  return "https://image.pollinations.ai/prompt/" + encodeURIComponent(String(prompt) + " high quality, detailed, professional composition") + "?width=1024&height=1024&nologo=true&enhance=true&seed=" + seed;
}

const IMAGE_MODELS = [
  "gemini-2.5-flash-image-preview",
  "gemini-3.1-flash-image-preview",
  "gemini-2.5-flash-image",
  "gemini-2.0-flash-exp",
];

function httpPost(url, body) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const d = JSON.stringify(body);
    const req = https.request({
      hostname: u.hostname, path: u.pathname + u.search, method: "POST",
      headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(d) }
    }, res => {
      let raw = "";
      res.on("data", c => raw += c);
      res.on("end", () => { try { resolve({ status: res.statusCode, data: JSON.parse(raw) }); } catch { resolve({ status: res.statusCode, data: raw }); } });
    });
    req.on("error", reject);
    req.setTimeout(60000, () => req.destroy(new Error("Timeout")));
    req.write(d); req.end();
  });
}

module.exports = async function handler(req, res) {
  applyCors(req, res, "POST, OPTIONS");
  if (handleOptions(req, res)) return;
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const body = req.body || {};
  const prompt = cleanText(body.prompt, 12000);
  if (!prompt) return res.status(400).json({ error: "No prompt provided" });

  const keys = getGeminiKeys();
  if (!keys.length) {
    return res.status(200).json({ imageUrl: fallbackImageUrl(prompt), provider: "free image fallback", fallback: true, warning: "No Gemini image key configured" });
  }

  let lastErr = null;

  for (let ki = 0; ki < keys.length; ki++) {
    const key = nextKey(keys);
    for (const model of IMAGE_MODELS) {
      try {
        const r = await httpPost(
          `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
          { contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseModalities: ["TEXT", "IMAGE"] } }
        );

        if (r.status === 200) {
          const parts = r.data?.candidates?.[0]?.content?.parts || [];
          const imgPart = parts.find(p => p.inlineData?.mimeType?.startsWith("image/"));
          if (imgPart) {
            const dataUrl = `data:${imgPart.inlineData.mimeType};base64,${imgPart.inlineData.data}`;
            return res.status(200).json({ imageUrl: dataUrl, isDataUrl: true, model });
          }
          lastErr = new Error(`${model}: no image in response`);
          continue;
        }
        if (r.status === 404 || r.status === 403) { lastErr = new Error(`${model}: HTTP ${r.status}`); continue; }
        if (r.status === 429) { lastErr = new Error("Rate limit"); break; }
        const msg = (r.data?.error?.message || JSON.stringify(r.data)).slice(0, 150);
        lastErr = new Error(`${model} HTTP ${r.status}: ${msg}`);
      } catch (e) { lastErr = e; }
    }
  }

  // Keep image mode usable when Gemini image generation is rate-limited.
  // This fallback is hosted and may also have its own fair-use limits.
  return res.status(200).json({
    imageUrl: fallbackImageUrl(prompt),
    provider: "free image fallback",
    fallback: true,
    warning: lastErr?.message || "Gemini image models were unavailable",
    tried: IMAGE_MODELS
  });
};
