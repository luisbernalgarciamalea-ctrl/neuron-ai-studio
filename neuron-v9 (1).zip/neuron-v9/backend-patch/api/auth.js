// Neuron AI — /api/auth — Global user accounts via MongoDB
const https = require("https");
const crypto = require("crypto");
const { applyCors, handleOptions } = require("./_security.js");

// Simple MongoDB REST via Data API (no driver needed in serverless)
// Uses MongoDB Atlas Data API
const MONGO_URI = process.env.MONGO_URI || "";
const DB_NAME = "neuron";
const COLLECTION = "users";

function hashPassword(pw) {
  return crypto.createHash("sha256").update(pw + "neuron_2024_salt").digest("hex");
}

// Developer access is deliberately server-side. Never put this value in browser code.
const DEV_PREMIUM_CODE = String(process.env.DEV_PREMIUM_CODE || "").trim();
function validDeveloperCode(input) {
  const supplied = String(input || "").trim().slice(0, 128);
  if (!DEV_PREMIUM_CODE || !supplied || supplied.length !== DEV_PREMIUM_CODE.length) return false;
  return crypto.timingSafeEqual(Buffer.from(supplied), Buffer.from(DEV_PREMIUM_CODE));
}

function publicUser(user) {
  return {
    name: user.name,
    email: user.email,
    plan: user.plan || "Free",
    isDeveloper: Boolean(user.isDeveloper)
  };
}

// Make a request to MongoDB Atlas Data API
// OR: fall back to direct driver if MONGO_DATA_API not set
function mongoRequest(action, body) {
  return new Promise((resolve, reject) => {
    const dataApiUrl = process.env.MONGO_DATA_API_URL; // optional Atlas Data API
    const dataApiKey = process.env.MONGO_DATA_API_KEY;

    if (!dataApiUrl || !dataApiKey) {
      // Fall back to native driver approach via dynamic import
      resolve(null);
      return;
    }

    const payload = JSON.stringify({
      dataSource: "GlobalStorageNeuronAI",
      database: DB_NAME,
      collection: COLLECTION,
      ...body
    });

    const url = new URL(dataApiUrl + "/action/" + action);
    const options = {
      hostname: url.hostname,
      path: url.pathname + url.search,
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "api-key": dataApiKey,
        "Content-Length": Buffer.byteLength(payload)
      }
    };

    const req = https.request(options, (res) => {
      let raw = "";
      res.on("data", c => raw += c);
      res.on("end", () => {
        try { resolve(JSON.parse(raw)); }
        catch { resolve({ error: raw }); }
      });
    });
    req.on("error", reject);
    req.setTimeout(10000, () => req.destroy(new Error("Timeout")));
    req.write(payload);
    req.end();
  });
}

// Native MongoDB driver (works in Vercel if mongodb is in package.json)
let _client = null;
async function getCollection() {
  if (!MONGO_URI) throw new Error("MONGO_URI not set");
  if (!_client) {
    const { MongoClient } = require("mongodb");
    _client = new MongoClient(MONGO_URI);
    await _client.connect();
  }
  return _client.db(DB_NAME).collection(COLLECTION);
}

module.exports = async function handler(req, res) {
  applyCors(req, res, "POST, OPTIONS");
  if (handleOptions(req, res)) return;
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { action, name, email, password, developerCode } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: "Email and password required" });

  const normalEmail = email.trim().toLowerCase();
  const hashedPw = hashPassword(password);

  try {
    const col = await getCollection();

    if (action === "register") {
      if (!name) return res.status(400).json({ error: "Name required" });

      const existing = await col.findOne({ email: normalEmail });
      if (existing) return res.status(409).json({ error: "An account with this email already exists. Please log in." });

      const developerAccess = validDeveloperCode(developerCode);
      if (developerCode && !developerAccess) {
        return res.status(401).json({ error: "Invalid developer code." });
      }

      const user = {
        name: name.trim(),
        email: normalEmail,
        password: hashedPw,
        plan: developerAccess ? "Premium" : "Free",
        isDeveloper: developerAccess,
        ...(developerAccess ? { developerActivatedAt: new Date().toISOString() } : {}),
        createdAt: new Date().toISOString()
      };

      await col.insertOne(user);
      return res.status(200).json({ success: true, user: publicUser(user) });
    }

    if (action === "login") {
      const user = await col.findOne({ email: normalEmail, password: hashedPw });
      if (!user) return res.status(401).json({ error: "Invalid email or password." });
      return res.status(200).json({ success: true, user: publicUser(user) });
    }

    if (action === "activateDeveloper") {
      const user = await col.findOne({ email: normalEmail, password: hashedPw });
      if (!user) return res.status(401).json({ error: "Invalid email or password." });
      if (!validDeveloperCode(developerCode)) {
        return res.status(401).json({ error: "Invalid developer code." });
      }

      await col.updateOne(
        { email: normalEmail },
        { $set: { plan: "Premium", isDeveloper: true, developerActivatedAt: new Date().toISOString() } }
      );
      return res.status(200).json({
        success: true,
        user: publicUser({ ...user, plan: "Premium", isDeveloper: true })
      });
    }

    // Paid plan changes must come from a future billing webhook, not the browser.
    if (action === "updatePlan") {
      return res.status(403).json({ error: "Plan changes are managed by the server." });
    }

    return res.status(400).json({ error: "Unknown action" });

  } catch (err) {
    console.error("Auth error:", err.message);
    // Fallback: local-only mode if DB unavailable
    return res.status(503).json({ error: "Database unavailable: " + err.message, fallback: true });
  }
};
