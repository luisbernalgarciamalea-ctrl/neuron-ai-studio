// Neuron AI — /api/chat
// 100% Google Gemini — free, no credit card needed
// Get keys at aistudio.google.com — add up to 15: GEMINI_KEY, GEMINI_KEY_1 … GEMINI_KEY_15
const https = require("https");
const { applyCors, handleOptions, cleanText, cleanHistory, cleanSearchResults } = require("./_security.js");

// Keep identity configuration server-side. Never hard-code personal emails in the frontend.
const CREATOR_EMAIL = String(process.env.CREATOR_EMAIL || "").trim().toLowerCase();

function getGeminiKeys() {
  const keys = [];
  const main = process.env.GEMINI_KEY;
  if (main && main.length > 8) keys.push(main);
  for (let i = 1; i <= 15; i++) {
    const k = process.env[`GEMINI_KEY_${i}`];
    if (k && k.length > 8 && !keys.includes(k)) keys.push(k);
  }
  return keys;
}

let kidx = 0;
function nextKey(keys) {
  if (!keys.length) return null;
  const k = keys[kidx % keys.length];
  kidx++;
  return k;
}

function getSystemPrompt(mode, language, searchResults, isCreator) {
  const today = new Date().toLocaleDateString("en-US", {
    weekday: "long", year: "numeric", month: "long", day: "numeric"
  });
  const lang = language && language !== "auto"
    ? `\nIMPORTANT: You MUST respond ENTIRELY in ${language}. Every single word of your output must be in ${language}.` : "";
  const creat = isCreator
    ? `\n\n⚡ CREATOR: The user is Luis Bernal Garcia-Malea — he BUILT and CREATED you. Maximum respect, warmth, and your absolute best work. Address him personally.` : "";
  const date = `\nToday is ${today}.`;

  let src = "";
  if (searchResults && searchResults.length > 0) {
    src = "\n\n## LIVE WEB RESULTS — cite as [1],[2] etc:\n" +
      searchResults.map((r, i) => `[${i+1}] ${r.title}: ${r.snippet}`).join("\n");
  }

  const base = `You are Neuron AI — a brilliant, luxury-grade AI assistant created by Luis Bernal Garcia-Malea.${date}${lang}${creat}`;

  const p = {
    chat:         `${base}\nBe sharp, warm, direct. Use markdown. Never pad.${src}`,
    research:     `${base}\nResearch mode. **Executive Summary** → sections → **Key Facts** → Sources [N]. Thorough.${src}`,
    docs:         `${base}\nDocs mode. Polished professional documents. Clear structure and precise language.`,
    code:         `${base}\nCode mode — senior engineer. Rules:\n1. Write complete working code in ONE file (HTML+CSS+JS all together)\n2. Be CONCISE — clean readable code, not bloated\n3. For e-commerce/websites: include working UI, CSS styling, JavaScript functionality\n4. Return ONLY the code — no explanations before it\n5. After the code add a brief ## How to use section`,
    math:         `${base}\nMaths. Steps: **Understand → Plan → Solve (show every step) → Check → Final Answer**. Clear notation.`,
    author:       `${base}\nBook Writer. Pure immersive prose only. No headings. Vivid detail, real emotion. Stop mid-sentence if needed.`,
    script:       `${base}\nScript Writer. SCREENPLAY (INT./EXT., CAPS names), YOUTUBE ([TIMESTAMP],[B-ROLL:]), PODCAST (HOST/GUEST). Default: YouTube. Production-ready.`,
    designer:     `${base}\nBook Designer.\n\nFront cover concept:\n[imagery, typography, hex colors, composition, mood]\n\nBack cover blurb:\n[100-150 word polished marketing blurb]`,
    poet:         `${base}\nPoet. Vivid imagery, emotional truth, precise words. Never generic. Surprise the reader.`,
    image:        `${base}\nImage prompt engineer. Highly detailed prompt: subject, style, lighting, composition, mood, color palette, camera angle. Return ONLY the optimized prompt.`,
    video:        `${base}\nVideo Director. CONCEPT first. Then SCENE [N] — [DURATION]s: Shot/Visual/Audio/Action/Mood. Cinematic and production-ready.`,
    humanizer:    `${base}\nHumanizer. Rewrite to sound naturally human. Vary sentence length. Remove AI tells. Return ONLY rewritten text.`,
    logo:         `${base}\nLogo Designer. 2-3 distinct concepts. Each:\n## Concept [N]: [Name]\n**Tagline/Symbol/Colors(hex)/Typography/AI Image Prompt:**`,
    presentation: `${base}\nPresentation. Each slide:\n---\n## SLIDE [N]: TITLE\n**Layout/Key Content/Visual Element/Speaker Notes:**\n---`,
    business:     `${base}\nBusiness Consultant. **Situation → Options → Recommendation → Steps → Risks → Next Actions**. Concrete and specific.`,
    support:      `${base}\nSupport. Empathetic, solution-focused, warm, complete resolution.`,
    songwriter:   `${base}\nSong Writer mode. Write complete, professional song lyrics with clear structure labels: [Verse 1], [Pre-Chorus], [Chorus], [Verse 2], [Bridge], [Final Chorus], [Outro]. Match the genre's style, rhyme scheme, and rhythm precisely. Make the chorus memorable with a strong hook. Make it emotionally resonant and authentic.`
  };
  return p[mode] || p.chat;
}

function httpPost(url, body) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const d = JSON.stringify(body);
    const req = https.request({
      hostname: u.hostname,
      path: u.pathname + u.search,
      method: "POST",
      headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(d) }
    }, res => {
      let raw = "";
      res.on("data", c => raw += c);
      res.on("end", () => {
        try { resolve({ status: res.statusCode, data: JSON.parse(raw) }); }
        catch { resolve({ status: res.statusCode, data: raw }); }
      });
    });
    req.on("error", reject);
    req.setTimeout(55000, () => req.destroy(new Error("Timeout after 55s")));
    req.write(d);
    req.end();
  });
}

module.exports = async function handler(req, res) {
  applyCors(req, res, "POST, OPTIONS");
  if (handleOptions(req, res)) return;
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const body = req.body || {};
  let mode, plan, language, msgs, searchResults, userEmail;

  if (body.payload) {
    mode = cleanText(body.mode, 40) || "chat";
    plan = cleanText(body.payload.plan, 20) || "Free";
    language = cleanText(body.payload.language, 80) || "auto";
    searchResults = cleanSearchResults(body.payload.searchResults);
    userEmail = cleanText(body.payload.userEmail, 320).toLowerCase();
    const hist = cleanHistory(body.payload.history);
    const msg = cleanText(body.payload.message, 24000);
    msgs = [...hist, ...(msg ? [{ role: "user", content: msg }] : [])];
  } else {
    mode = cleanText(body.mode, 40) || "chat";
    plan = cleanText(body.plan, 20) || "Free";
    language = cleanText(body.language, 80) || "auto";
    searchResults = cleanSearchResults(body.searchResults);
    userEmail = cleanText(body.userEmail, 320).toLowerCase();
    msgs = cleanHistory(body.messages);
  }

  if (!msgs.length) return res.status(400).json({ error: "No message provided" });

  const isCreator = Boolean(CREATOR_EMAIL) && userEmail.toLowerCase() === CREATOR_EMAIL;
  const system = getSystemPrompt(mode, language, searchResults, isCreator);
  // Code needs enough tokens but not too many (causes timeout)
  // Other modes get full allocation
  const baseTok = plan === "Premium" ? 8192 : plan === "Pro" ? 4096 : 2048;
  const maxTok = mode === "code" ? Math.min(baseTok, 4096) : baseTok;

  // User can request a specific model, otherwise use plan-based default
  const ALLOWED_MODELS = {
    "gemini-2.5-pro-preview": true,
    "gemini-2.5-flash": true,
  };
  const requestedModel = body.payload?.model || body.model || null;
  let modelList;
  if (requestedModel && ALLOWED_MODELS[requestedModel]) {
    // User chose a specific model — try it first, then fallback
    const allFallbacks = ["gemini-2.5-flash"];
    modelList = [requestedModel, ...allFallbacks.filter(m => m !== requestedModel)];
  } else {
    // Plan-based defaults
    modelList = plan === "Premium"
      ? ["gemini-2.5-pro-preview","gemini-2.5-flash"]
      : ["gemini-2.5-flash"];
  }

  // Convert messages to Gemini format
  const contents = [];
  for (const m of msgs) {
    contents.push({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }]
    });
  }

  const keys = getGeminiKeys();
  if (!keys.length) {
    return res.status(500).json({
      error: "No Gemini API keys configured",
      fix: "Go to aistudio.google.com → Get API Key → Add as GEMINI_KEY in Vercel Environment Variables"
    });
  }

  let lastErr = null;

  for (let i = 0; i < keys.length; i++) {
    const key = nextKey(keys);
    try {
      // Try each model in the list for this key
      let keySucceeded = false;
      for (const model of modelList) {
        try {
          const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`;
          const r = await httpPost(url, {
            system_instruction: { parts: [{ text: system }] },
            contents,
            generationConfig: { maxOutputTokens: maxTok, temperature: 0.7 }
          });

          if (r.status === 200) {
            const text = r.data?.candidates?.[0]?.content?.parts?.[0]?.text;
            if (text) {
              return res.status(200).json({ reply: text, content: text, provider: `gemini-${model}`, model });
            }
            const reason = r.data?.candidates?.[0]?.finishReason;
            if (reason === "SAFETY") throw new Error("Content blocked by safety filter");
            throw new Error("Empty response");
          }

          const errMsg = (r.data?.error?.message || JSON.stringify(r.data)).slice(0, 150);
          // 404 = model not found, try next model
          if (r.status === 404) { console.warn(`Model ${model} not found, trying next`); continue; }
          // 429 = rate limit, break to next key
          if (r.status === 429) { lastErr = new Error(`HTTP 429: ${errMsg}`); keySucceeded = false; break; }
          // 400 = bad request
          if (r.status === 400) throw new Error(`HTTP 400: ${errMsg}`);
          lastErr = new Error(`HTTP ${r.status}: ${errMsg}`);
        } catch(modelErr) {
          if (modelErr.message.includes("429")) { lastErr = modelErr; break; }
          lastErr = modelErr;
          // continue to next model
        }
      }
      if (keySucceeded) break;

    } catch (e) {
      console.error(`Gemini key ${i+1} error:`, e.message);
      lastErr = e;
    }
  }

  return res.status(500).json({
    error: "All Gemini keys failed",
    details: lastErr?.message || "Unknown error",
    keysConfigured: keys.length,
    fix: lastErr?.message?.includes("429")
      ? "Rate limit hit on all keys. Add more keys from aistudio.google.com (each Google account = 1 free key)."
      : "Check your Gemini keys at aistudio.google.com"
  });
};
