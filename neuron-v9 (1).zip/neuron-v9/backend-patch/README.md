# Backend patches for neuron-backend-v2

Copy these files into the root of the GitHub backend repository:

- `api/auth.js` — MongoDB-backed registration/login with server-side developer Premium-code validation
- `api/health.js` — safe status endpoint
- `api/music.js` — lyrics/production-brief endpoint
- `api/video-status.js` — asynchronous JSON2Video status endpoint that reads the provider `movie` response correctly
- `vercel.json` — route/function configuration

These patches do not include any API keys or secret values.

## Vercel variables

Set secrets only in Vercel Project Settings → Environment Variables:

- `GEMINI_KEY`
- `GEMINI_KEY_1` … only if you are legitimately allowed to use additional accounts/keys
- `SERPER_KEY` (optional)
- `JSON2VIDEO_KEY` (optional)
- `MONGO_URI` — the MongoDB connection string for the `neuron` database
- `DEV_PREMIUM_CODE` — a separate private developer code; never put its value in frontend JavaScript
- `FRONTEND_ORIGIN` (recommended, set to your actual deployed frontend URL)

Do not commit `.env`, API keys, passwords, developer codes, or database connection strings.

## Developer Premium access

The V8 frontend already contains an optional developer-code field on signup and login. It now sends the entered value to `/api/auth`; the backend checks it against the server-only `DEV_PREMIUM_CODE` variable and stores `plan: "Premium"` and `isDeveloper: true` in MongoDB.

New registrations always start as `Free` unless the server validates the developer code. Browser-supplied `plan` values can no longer change an account plan, and the old unrestricted `updatePlan` action is rejected.

The developer code value is intentionally not included in this patch. Create a new private value in Vercel. Do not use a code that has been exposed in chat or source control for production.

## Media fixes

The updated `api/image.js` returns a labelled free fallback image URL when Gemini image generation is rate-limited. The updated `api/video.js` creates real cinematic scene images through JSON2Video's `flux-schnell` image element and returns the project identifier immediately. The updated `api/video-status.js` reads JSON2Video's `{ movie: { ... } }` response correctly, so completed jobs no longer remain stuck at `processing`.
