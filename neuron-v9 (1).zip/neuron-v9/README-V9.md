# Neuron AI V9

This package contains the current Neuron frontend/backend patch, including:

- MongoDB-backed authentication
- Server-validated developer Premium access
- Updated signup and login developer-code fields
- Safe image seed handling
- Asynchronous video status flow with real AI-generated scene images and corrected JSON2Video status parsing
- The new Neuron gold circuit-tree logo

## Developer Premium setup

In the backend Vercel project, add this environment variable:

```text
DEV_PREMIUM_CODE=your-private-developer-code
```

Use the same value in the frontend developer-code field after the backend is deployed. Do not put the value into frontend JavaScript, commit it to GitHub, or use it as the MongoDB password.

The code is intentionally not hardcoded in this package. The previously shared value `95768_DEV` should be considered exposed and should only be used for temporary testing.

## Deployment

### Backend

Copy the contents of `backend-patch/` into the GitHub backend repository, including the updated:

```text
api/auth.js
```

Add `DEV_PREMIUM_CODE` in Vercel, save it for Production, and redeploy.

### Frontend

Deploy either:

```text
frontend/index.html
```

or:

```text
frontend/neuron.html
```

along with the frontend assets and vendor folder.

## Test

1. Open the deployed frontend in an incognito window.
2. Create a new account or log in.
3. Enter the developer code in the optional developer-code field.
4. Confirm that the account plan displays `Premium`.
