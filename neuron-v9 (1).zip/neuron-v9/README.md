# Neuron AI V8

This is an improved frontend package built from the uploaded `neuron-V7.html`. The original files were not overwritten.

## Files

- `frontend/index.html` — improved frontend entry point
- `frontend/neuron.html` — same frontend, retained as a named copy
- `frontend/neuron-logo.png` — logo
- `frontend/vendor/` — local DOCX and PowerPoint libraries used by downloads
- `frontend/vercel.json` — basic browser security headers
- `backend-patch/api/health.js` — optional backend health endpoint
- `backend-patch/api/music.js` — fixes the duplicated music endpoint and generates original lyrics/production briefs
- `docs/IMPROVEMENT-PLAN.md` — product, security, AI, memory, media, and SEO roadmap
- `docs/FREE-API-REALITY.md` — honest free/unlimited API options
- `docs/PUBLISHING.md` — free hosting and domain/SEO instructions

## Run the frontend locally

From this folder:

```bash
python3 -m http.server 8080 --directory frontend
```

Then open `http://localhost:8080`.

The page uses the deployed backend by default:

```text
https://neuron-backend-v2.vercel.app
```

To use another backend, add this line before the main application script:

```html
<script>window.NEURON_BACKEND_URL = "https://your-backend.vercel.app";</script>
```

## Verify the current backend

```bash
curl -X OPTIONS https://neuron-backend-v2.vercel.app/api/chat
curl "https://neuron-backend-v2.vercel.app/api/search?q=artificial%20intelligence"
curl -X POST https://neuron-backend-v2.vercel.app/api/chat \
  -H 'Content-Type: application/json' \
  -d '{"mode":"chat","payload":{"message":"Reply with exactly: connection ok","plan":"Free","history":[],"searchResults":[],"language":"English"}}'
```

Never put Gemini, Serper, MongoDB, or video provider keys in this frontend folder or in a public repository.
